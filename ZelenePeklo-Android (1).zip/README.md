# Zelené peklo – Android projekt

Survival hra (three.js) zabalená do Android WebView, vždy na šírku a fullscreen.

## Build na GitHube
Po nahratí do repozitára (vetva main) sa APK zbuilduje automaticky v záložke Actions. Hotový súbor je v sekcii Artifacts (ZelenePeklo-APK). Build môžeš spustiť aj ručne cez Run workflow.

## Alebo lokálne (Android Studio)
1. Otvor priečinok v Android Studiu (Hedgehog alebo novší, JDK 17).
2. Počkaj na Gradle sync (vygeneruje aj gradlew).
3. Build > Build APK(s), alebo tlačidlo Run s pripojeným telefónom.

## Poznámka
Hra načíta knižnicu three.js z internetu (cdnjs). Na offline beh stiahni
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js do
app/src/main/assets/three.min.js a v assets/index.html zmeň src skriptu na "three.min.js".

Hra je v app/src/main/assets/index.html.

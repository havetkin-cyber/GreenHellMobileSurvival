#!/usr/bin/env bash
# Stiahne volne low-poly modely (CC0 / CC-BY) do app/src/main/assets/models
set +e
D="$(cd "$(dirname "$0")" && pwd)"
M="$D/app/src/main/assets/models"
T="$(mktemp -d)"
mkdir -p "$M"

dl() { curl -L --fail --silent --show-error -o "$2" "$1"; }

# Lisa (animovany model, pouzity ako vlk)
dl "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/Fox/glTF-Binary/Fox.glb" "$M/wolf.glb"

# Kenney Nature Kit (stromy, skaly, kry) - CC0
mkdir -p "$T/nk"
NK="https://kenney.nl/media/pages/assets/nature-kit/37ac38a37b-1677698939/kenney_nature-kit.zip"
(cd "$T/nk" && dl "$NK" kit.zip && unzip -q kit.zip) || {
  NK2=$(curl -sL https://kenney.nl/assets/nature-kit | grep -oE 'https://kenney\.nl/media/pages/assets/nature-kit/[^")]+\.zip' | head -1)
  [ -n "$NK2" ] && (cd "$T/nk" && dl "$NK2" kit.zip && unzip -q kit.zip)
}

# Kenney Survival Kit (taborak, spaci vak, sudy, truhla) - CC0
mkdir -p "$T/sk"
SK="https://kenney.nl/media/pages/assets/survival-kit/4065a8185b-1712149243/kenney_survival-kit.zip"
(cd "$T/sk" && dl "$SK" kit.zip && unzip -q kit.zip) || {
  SK2=$(curl -sL https://kenney.nl/assets/survival-kit | grep -oE 'https://kenney\.nl/media/pages/assets/survival-kit/[^")]+\.zip' | head -1)
  [ -n "$SK2" ] && (cd "$T/sk" && dl "$SK2" kit.zip && unzip -q kit.zip)
}

# pick <kit> <cielovy-subor> <vzor1> <vzor2> ...
pick() {
  d="$T/$1"; out="$M/$2"; shift 2
  for p in "$@"; do
    f=$(find "$d" -iname "$p" | head -1)
    if [ -n "$f" ]; then cp "$f" "$out"; echo "OK    $(basename "$out") <- $f"; return 0; fi
  done
  echo "CHYBA nenasiel som $(basename "$out")"
  return 0
}

pick nk pine.glb  tree_pineTallA.glb 'tree_pine*.glb'
pick nk oak.glb   tree_oak.glb tree_default.glb
pick nk rock.glb  rock_largeA.glb 'rock_large*.glb'
pick nk bush.glb  plant_bush.glb 'plant_bush*.glb'
pick sk campfire.glb campfire-pit.glb campfire.glb '*campfire*.glb'
pick sk bed.glb      bedroll.glb '*bedroll*.glb' '*bed*.glb'
pick sk barrel.glb   barrel.glb '*barrel*.glb'
pick sk bag.glb      chest.glb box.glb '*chest*.glb' '*box*.glb'

echo "--- Survival Kit modely ---"
find "$T/sk" -iname '*.glb' -exec basename {} \; | sort | tr '\n' ' '
echo
echo "--- vysledok ---"
ls -la "$M"
exit 0

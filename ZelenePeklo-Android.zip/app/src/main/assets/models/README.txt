Sem patria volitelne 3D modely zvierat vo formate GLB:

  deer.glb   (jelen)
  wolf.glb   (vlk)

Ak subory chybaju, hra pouzije vstavane low-poly zvierata.
Odporucane zdarma (CC0): Quaternius "Ultimate Animated Animals" (animovane, walk/gallop/idle).
Animacie sa vyberaju podla nazvu (walk, gallop alebo run). Velkost sa prisposobi automaticky.
Ak je zviera otocene opacne, zmen MODEL_ROT v index.html (napr. na 3.14159).
